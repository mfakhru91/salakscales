<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tonase extends Model
{
    //
}
