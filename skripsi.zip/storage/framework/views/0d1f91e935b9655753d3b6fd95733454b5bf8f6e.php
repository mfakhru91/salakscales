<?php $__env->startSection('title'); ?>Pembelian edit <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="panel">
    <div class="panel-heading">
      <h3 class="panel-title">edit pembeli</h3>
    </div>
    <div class="panel-body">
      <form class="" action="<?php echo e(route('pembelian.update',$seller->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
          <label for="name">Nama</label>
          <input type="text" class="form-control " name="name" value="<?php echo e($seller->name); ?>" placeholder="Nama Pembeli">
        </div>
        <?php if($errors->has('name')): ?>
          <span class="help-block"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
        <div class="form-group <?php echo e($errors->has('address')? 'has-error':''); ?>">
          <label for="address">Alamat</label>
          <input type="text" class="form-control" name="address" value="<?php echo e($seller->address); ?>" placeholder="Alamat">
        </div>
        <?php if($errors->has('address')): ?>
          <span class="help-block" ><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
        <label for="no_telp">No Telp</label>
        <div class="input-group <?php echo e($errors->has('no_telp')? 'has-error':''); ?> ">
          <span class="input-group-addon">+62</span>
          <input type="text" class="form-control" name="no_telp" value="<?php echo e($seller->no_telp); ?>" placeholder="No Telp">
        </div>
        <small>* contoh no telp 8233628373 <b>tanpa 0</b>.</small>
        <?php if($errors->has('no_telp')): ?>
          <span class="help-block" ><?php echo e($errors->first('no_telp')); ?></span>
        <?php endif; ?>
    </div>
    <div class="panel-footer">
      <button type="submit" class="btn btn-primary">Tambah +</button>
    </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/salakscales/resources/views/users/pembelian/edit.blade.php ENDPATH**/ ?>