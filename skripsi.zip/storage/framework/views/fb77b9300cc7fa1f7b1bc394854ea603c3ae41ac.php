<div id="sidebar-nav" class="sidebar">
  <div class="sidebar-scroll">
    <nav>
      <ul class="nav">
        <li><a href="<?php echo e(route('dashboard.index')); ?>" class="<?php echo e(Request::routeIs('dashboard.index') ? 'active' : ''); ?>"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
        <li>
          <a href="#subPages" data-toggle="collapse" class="collapsed <?php if(Request::routeIs('pembelian.index') || Request::routeIs('penjualan.index')): ?> active <?php endif; ?>"><i class="lnr lnr-users"></i> <span>Transaksi</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
          <div id="subPages" class="collapse ">
            <ul class="nav">
              <li><a href="<?php echo e(route('pembelian.index')); ?>" class="<?php echo e(Request::routeIs('pembelian.index') ? 'active' : ''); ?>"><i class="lnr lnr-cart"></i><span>Pembelian</span></a></li>
              <li><a href="<?php echo e(route('penjualan.index')); ?>" class="<?php echo e(Request::routeIs('penjualan.index') ? 'active' : ''); ?>"><i class="lnr lnr-briefcase"></i><span>Penjualan</span></a></li>
            </ul>
          </div>
        </li>
        <li><a href="<?php echo e(route('barang.index')); ?>" class="<?php echo e(Request::routeIs('barang.index')? 'active' : ''); ?>"><i class="lnr lnr-database"></i><span>Barang</span></a></li>
        <li><a href="<?php echo e(route('pembelian.index')); ?>" class=""><i class="lnr lnr-book"></i><span>Pembukuan</span></a></li>
        <li><a href="<?php echo e(route('pembelian.index')); ?>" class=""><i class="lnr lnr-calendar-full"></i><span>Kalender</span></a></li>
        <li><a href="<?php echo e(route('setting.index')); ?>" class=""><i class="lnr lnr-cog"></i> <span>Setting</span></a></li>
      </ul>
    </nav>
  </div>
</div>
<?php /**PATH E:\xampp\htdocs\salakscales\resources\views/layouts/includes/_sidebar.blade.php ENDPATH**/ ?>