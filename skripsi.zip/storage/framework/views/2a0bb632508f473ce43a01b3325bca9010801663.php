
<?php $__env->startSection('title'); ?> Buku Besar <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php
$arr_laba_kotor = [];
$arr_additional_item = [];
?>
<?php if($profit == null || $profit == '0'): ?>
array_push($arr_laba_kotor,"0");
array_push($arr_additional_item,"0");
<?php else: ?>
<?php $__currentLoopData = $profit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $by): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $laba_kotor = $by->income - $by->price - ($by->tools * $by->tonase) - ($by->packing * $by->tonase) - ($by->shipping_charges);
        array_push($arr_laba_kotor,$laba_kotor);
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $additem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
       $get_price = $item->unit * $item->price;
       array_push($arr_additional_item,$get_price);
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php
    $laba_kotor_total = array_sum($arr_laba_kotor);
    $additional_item_total = array_sum($arr_additional_item);
    $lastIncome = $laba_kotor_total - $additional_item_total;
?>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">Buku Besar</h3>
    </div>
    <div class="panel-body">
        <form action="<?php echo e(route('jurnal-ledger.index')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-2" >
                    <div class="input-group">
                        <input class="form-control datepicker" <?php if($date_selected == null): ?> placeholder="Pilih Bulan" <?php else: ?> value="<?php echo e($date_selected); ?>" <?php endif; ?> id="month" type="datetime" name="date_from">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </div>
            <br>
        </form>
        <table class="table table-striped table-bordered" id="exportBukuBesar">
            <thead>
                <tr>
                    <th class="text-center" colspan="5">
                        <h3>Laporan Buku Besar</h3>
                        Catatan laporan buku besar antara tanggal
                    </th>
                </tr>
                <tr>
                    <th>Keterangan</th>
                    <th>Tanggal Transaksi</th>
                    <th>Debet</th>
                    <th>Kredit</th>
                    <th>Saldo</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Keuntungan Bulan Lalu</td>
                    <td><?php echo e($last_date); ?></td>
                    <td>Rp. 0,00</td>
                    <td>Rp. 0,00</td>
                    <td>
                        <?php if($lastIncome <= 0): ?>
                        Rp. 0,00
                        <?php else: ?>
                        Rp. <?php echo e(number_format($lastIncome , 2, ',', '.')); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($dt->description); ?></td>
                    <td><?php echo e($dt->date); ?></td>
                    <?php if($dt->status == "debet"): ?>
                        <td>Rp. <?php echo e(number_format($dt->nominal , 2, ',', '.')); ?></td>
                        <td>Rp. 0,00</td>
                    <?php else: ?>
                        <td>Rp. 0,00</td>
                        <td>Rp. <?php echo e(number_format($dt->nominal , 2, ',', '.')); ?></td>
                    <?php endif; ?>
                    <td>
                        <?php
                            if($dt->status == "kredit")
                            {
                                $lastIncome = $lastIncome - $dt->nominal;
                            }else{
                                $lastIncome = $lastIncome + $dt->nominal;
                            }
                        ?>
                        Rp. <?php echo e(number_format($lastIncome , 2, ',', '.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button class="export-costume btn btn-primary btn-block" id="exportPembelian">
            Export
        </button>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="<?php echo e(asset('public/js/table2excel.js')); ?>"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $( document ).ready(function() {
        console.log( "ready!" );
        $("#month").datepicker({
            dateFormat: 'yy-mm',
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,

            onClose: function (dateText, inst) {
              var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
              var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
              $(this).val($.datepicker.formatDate('yy-mm', new Date(year, month, 1)));
            }
          });
        $("#month").focus(function () {
            $(".ui-datepicker-calendar").hide();
            $("#ui-datepicker-div").position({
              my: "center top",
              at: "center bottom",
              of: $(this)
            });
          });
        $("#dateTo").datepicker({
            dateFormat: 'yy-mm-dd'
        })
        $("#exportCostume").click(function(){
            var table2excel = new Table2Excel({
                defaultFileName: "Bookkeeping Costume",
                Number : true,
            }
            );
            table2excel.export(document.getElementsByClassName("costume-export"));
        })
        $("#exportPembelian").click(function(){
            const dateFrom = $("#dateFrom").val()
            const dateTo = $("#dateTo").val()
            if( dateFrom == '' || dateTo == ''){
                alert("pilih tanggal atau pembayaran terlebih dahulu")
            }else{
                var table2excel = new Table2Excel({
                    defaultFileName: "Laporan Buku Besar",
                    Number : true,
                }
                );
                table2excel.export(document.getElementById("exportBukuBesar"));
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/jurnal-ledger/index.blade.php ENDPATH**/ ?>