
<?php $__env->startSection('title'); ?>Pembelian <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">Setting</h3>
    </div>
    <div class="panel-body">
        <form class="" action="<?php echo e(route('setting.update',$user->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <div class="form-group row">
                <label for="userName" class="col-sm-2 col-form-label">Nama Pengguna</label>
                <div class="col-sm-10">
                    <input type="Text" class="form-control" id="userName" name="username" placeholder="Nama Pengguna" value="<?php echo e($user->name); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="price" class="col-sm-2 col-form-label">Harga Pasar</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="price" name="price" placeholder="Harga Pasar" value="<?php echo e($settings->price); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="price" class="col-sm-2 col-form-label">Harga Pasar</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="shellPrice" name="sellprice" placeholder="Harga Pasar" value="<?php echo e($settings->sell_price); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="tools" class="col-sm-2 col-form-label">Alat</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="tools" name="tools" placeholder="Id Alat" value="<?php echo e($settings->tools_id); ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\salakscales\resources\views/users/setting/index.blade.php ENDPATH**/ ?>