<?php $__env->startSection('title'); ?>Print Data <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
  <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="panel">
    <div class="panel-heading">
      <h3 class="panel-title">PRINT NOTA</h3>
    </div>
    <div class="panel-body" id="nota">
      <div class="row">
        <div class="col-xs-4  ">
          <table class="">
            <tr>
              <td style="width: 90px;">Date</td>
              <td style="width: 30px;">:</td>
              <td><?php echo e(now()->format('d M Y')); ?></td>
            </tr>
            <tr>
              <td>Nama</td>
              <td>:</td>
              <td><?php echo e($seller->name); ?></td>
            </tr>
          </table>
        </div>
        <div class="col">

        </div>
      </div>
      <hr>
      <table class="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Pembayaran</th>
            <th>Tonase</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->date($item->created_at)); ?></td>
            <td><?php echo e($item->payment); ?></td>
            <td><?php echo e($item->tonase); ?> Kg</td>
            <td>Rp.<?php echo e($item->price); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr >
            <td colspan="2" class="text-right">
              <b>Total</b>
            </td>
            <td> <?php echo e($items->sum('tonase')); ?> Kg</td>
            <td>Rp.<?php echo e($items->sum('price')); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="panel-footer">
      <div class="row">
        <div class="col-md-1">
          <button type="button"  class="btn btn-info" onclick="printJS({ printable: 'nota', type: 'html', css:'https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css' })">
            <span class="lnr lnr-printer"></span> Print
          </button></div>
        <div class="col-md-1">
          <form action="<?php echo e(route('note.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="hidden" name="item_id[<?php echo e($item->id); ?>]" value="<?php echo e($item->id); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <input type="hidden" name="price_total" value="<?php echo e($items->sum('price')); ?>">
            <input type="hidden" name="tonase_total" value="<?php echo e($items->sum('tonase')); ?>">
            <button class="btn btn-primary"><span class="lnr lnr-file-empty"></span> Save</button>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/salakscales/resources/views/users/barang/print.blade.php ENDPATH**/ ?>