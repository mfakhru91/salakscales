
<?php $__env->startSection('title'); ?> Edit Barang  <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/laporan.css')); ?>">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title">Edit Data</h3>
		</div>
		<div class="panel-body">
            <form action="<?php echo e(route('bookkeeping.update',$item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                <div class="form-group">
                    <label for="name">Tanggal Pembelian</label>
                    <input type="text" class="form-control" id="date" name="date" data-toggle="datepicker" value="<?php echo e($item->date); ?>" placeholder="tanggal pembelian">
                    <?php if($errors->has('date')): ?>
                        <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="name">Nama Barang</label>
                    <input type="text" class="form-control" id="itemName" name="item_name" value="<?php echo e($item->name); ?>" placeholder="nama barang">
                    <?php if($errors->has('item_name')): ?>
                        <span class="help-block"><?php echo e($errors->first('item_name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="unit">Jumlah Barang</label>
                    <input type="number" class="form-control" id="itemUnit" name="item_unit" value="<?php echo e($item->unit); ?>" placeholder="jumlah barang">
                    <?php if($errors->has('item_unit')): ?>
                        <span class="help-block"><?php echo e($errors->first('item_unit')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="unit">Harga Barang</label>
                    <input type="number" class="form-control" id="itemUnit" name="item_price" value="<?php echo e($item->price); ?>" placeholder="harga barang">
                    <?php if($errors->has('item_price')): ?>
                        <span class="help-block"><?php echo e($errors->first('item_price')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="panel-footer">
                <button type="submit" class="btn btn-primary">Tambah Barang</button>
            </form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $( document ).ready(function() {
        console.log( "ready!" );
        $( "#date" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/bookkeeping/edit.blade.php ENDPATH**/ ?>