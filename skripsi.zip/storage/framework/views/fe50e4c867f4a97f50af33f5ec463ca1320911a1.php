<?php $__env->startSection('title'); ?> barang <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-warning alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
     <i class="fa fa-check-circle"></i> <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form class="" action="<?php echo e(route('barang.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="payment">Pembeli</label>
                  <select class="form-control" name="seller_id">
                    <option value="" selected>Pembeli</option>
                    <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    	<option value="<?php echo e($seller->id); ?>"><?php echo e($seller->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('seller_id')): ?>
                        <span class="help-block"><?php echo e($errors->first('seller_id')); ?></span>
                  <?php endif; ?>
                </div>
                <label for="tonase">Tonase</label>
                <div class="input-group">
                  <input type="text" class="form-control" name="tonase" id="tonase" value="">
                  <span class="input-group-addon">Kg</span>
                </div>
                <?php if($errors->has('tonase')): ?>
                      <span class="help-block"><?php echo e($errors->first('tonase')); ?></span>
                <?php endif; ?>
                <a href="#" class="btn btn-primary" style="margin-top: 10px" id="get-tonase">Timbang</a>
                <br>
                <label for="price">Harga</label>
                <div class="input-group">
                  <span class="input-group-addon">Rp</span>
                  <input type="text" class="form-control" name="price" id="price" value="">
                </div>
                <?php if($errors->has('price')): ?>
                      <span class="help-block"><?php echo e($errors->first('price')); ?></span>
                <?php endif; ?>
                <div class="form-group">
                  <label for="payment">Pembayaran</label>
                  <select class="form-control" name="payment">
                    <option value="" selected>Pembayaran</option>
                    <option value="debt">Hutang</option>
                    <option value="paid off">Lunas</option>
                  </select>
                  <?php if($errors->has('payment')): ?>
                        <span class="help-block"><?php echo e($errors->first('payment')); ?></span>
                  <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Tambah Barang <i class="lnr lnr-plus-circle"></i></button>
              </form>
            </div>
          </div>
        </div>
      </div>
	<div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title">Daftar Barang</h3>
		</div>
		<div class="panel-body">
      <button type="button" class="btn btn-primary mb-3" data-toggle="modal" data-target="#exampleModal">
        Tambah Pelajaran <i class="lnr lnr-plus-circle"></i>
      </button>
      <form style="margin-top: 10px" action="<?php echo e(route('barang.delivery')); ?>" id="delivery" method="POST">
        <?php echo csrf_field(); ?>
      <a href="#" id="send" class="btn btn-primary" onclick="alert(apakah anda yakin)">Kirim</a>
			<table class="table table-striped">
				<thead>
					<tr>
            <th> <input class="form-check-input" type="checkbox" id="checkall" value="option2"> </th>
						<th>NAMA PENJUAL</th>
						<th>TONASE</th>
						<th>HARGA</th>
						<th>PEMBAYARAN</th>
						<th>NO NOTA</th>
            <th>STATUS</th>
						<th>ACTION</th>
					</tr>
				</thead>
				<tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $sellers->where('id',$item->seller_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <input class="form-check-input itemchecked" type="checkbox" name="item[]" value="<?php echo e($item->id); ?>"> </td>
            </form>
              <td><a href="<?php echo e(route('pembelian.show',$seller->id)); ?>" class="text-info"><?php echo e($seller->name); ?></a></td>
              <td><?php echo e($item->tonase); ?></td>
              <td>Rp. <?php echo e(number_format($item->price, 2, ',', '.')); ?></td>
              <td>
                <?php if($item->payment == 'debt'): ?>
                  Hutang
                <?php else: ?>
                  Lunas
                <?php endif; ?>
              </td>
              <td>
                <form action="<?php echo e(route('print.note')); ?>" id="note" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="saller_id" value="<?php echo e($item->seller_id); ?>">
                  <input type="hidden" name="note" value="<?php echo e($item->note_id); ?>">
                  <?php if($item->note_id): ?>
                  <button type="submit" class="btn btn-light"><span class="lnr lnr-printer"></span> <?php echo e($item->note_id); ?></button>
                  <?php endif; ?>
                </form>
						  </td>
              <td>
              <?php if($item->status == 'process'): ?>
              proses
              <?php else: ?>
              <b>terjual</b>
              <?php endif; ?>
              </td>
              <td>
                <a href="<?php echo e(route('barang.edit',$item->id)); ?>" class="btn btn-warning"><i class="lnr lnr-pencil"></i></a>
                <a href="<?php echo e(route('item.delete',$item->id)); ?>" class="btn btn-danger"><span class="lnr lnr-trash"></span></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
		</div>
  </div>
  <div class="panel">
    <div class="panel-heading">
      <h3 class="panel-title">Barang Kirim</h3>
    </div>
    <div class="panel-body">
      <table class="table table-striped">
				<thead>
					<tr>
						<th>NAMA PENJUAL</th>
						<th>TONASE</th>
						<th>HARGA</th>
						<th>PEMBAYARAN</th>
						<th>NO NOTA</th>
            <th>STATUS</th>
						<th>ACTION</th>
					</tr>
				</thead>
				<tbody>
            <?php $__currentLoopData = $dvitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $dvsellers->where('id',$item->seller_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('pembelian.show',$seller->id)); ?>" class="text-info"><?php echo e($seller->name); ?></a></td>
              <td><?php echo e($item->tonase); ?></td>
              <td>Rp. <?php echo e(number_format($item->price, 2, ',', '.')); ?></td>
              <td>
                <?php if($item->payment == 'debt'): ?>
                  Hutang
                <?php else: ?>
                  Lunas
                <?php endif; ?>
              </td>
              <td>
                <form action="<?php echo e(route('print.note')); ?>" id="note" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="saller_id" value="<?php echo e($item->seller_id); ?>">
                  <input type="hidden" name="note" value="<?php echo e($item->note_id); ?>">
                  <?php if($item->note_id): ?>
                  <button type="submit" class="btn btn-light"><span class="lnr lnr-printer"></span> <?php echo e($item->note_id); ?></button>
                  <?php endif; ?>
                </form>
						  </td>
              <td>
              <?php if($item->status == 'process'): ?>
              proses
              <?php else: ?>
              <b>terjual</b>
              <?php endif; ?>
              </td>
              <td>
                <a href="<?php echo e(route('barang.edit',$item->id)); ?>" class="btn btn-warning"><i class="lnr lnr-pencil"></i></a>
                <a href="<?php echo e(route('item.delete',$item->id)); ?>" class="btn btn-danger"><span class="lnr lnr-trash"></span></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  const app_url = "<?php echo e(config('app.url')); ?>"
  const user_id = <?php echo e($user); ?>

  function noteSubmit() {
    document.getElementById("note").submit();
  }
  $(document).ready(function() {
    $('#get-tonase').click(function(){
      $.ajax({
        url:app_url+"/api/setting/"+user_id,
        type:"GET",
        async : true,
        success:function(result)
        {
          var tools_id = result.data[0].tools_id
          if( tools_id  == null ){
            alert('Anda belum memasukan Id alat')
          }
          $.ajax({
            url:app_url+"/api/tonase?tools_id="+tools_id,
            type:"GET",
            async : true,
            success:function(result)
            {
              let tonase = result.data[0].tonase
              $("#tonase").val(tonase)
            }
          });
        }
      });
    })
    $('#price').click(function(){
      $.ajax({
        url:app_url+"/api/setting/"+user_id,
        type:"GET",
        async : true,
        success:function(result)
        {
          console.log(result)
          let priceData = result.data[0].price
          let getTonase = $('#tonase').val()
          let sumPrice = getTonase * priceData
          $('#price').val(sumPrice)
        }
      });
    })
    $('#send').click(function(){
      var response = confirm("Apakah Anda Yakin?");
      if ( response == true )
      {
        $('#delivery').submit();
      }else{

      }
    })
    $('#checkall').click(function() {
      if($('#checkall').prop('checked')== true){
        $('.itemchecked').prop('checked',true)
      }else{
        $('.itemchecked').prop('checked',false)
      }
    })
    $('.itemchecked').click(function() {
      $('#checkall').prop('checked',false)
    })
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/barang/index.blade.php ENDPATH**/ ?>