
<?php $__env->startSection('title'); ?> barang <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/laporan.css')); ?>">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-warning alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
     <i class="fa fa-check-circle"></i> <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">Pembelian Lainya</h3>
    </div>
    <div class="panel-body">
        <form action="<?php echo e(route('additional-item.export')); ?>" method="GET">
            <div class="row" style="margin-bottom: 10px;">
                <div class="col-md-2" >
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input class="form-control datepicker" placeholder="dari tanggal" id="datefrom" type="datetime" name="from">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2" >
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input class="form-control datepicker" placeholder="sampai tanggal" id="dateto" type="datetime" name="to">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </div>
        </form>

        <div class="row">
            <div class="col-md-9">
                <table style="margin-top: 10px" class="table table-striped table-bordered"  id="export" style="counter-reset: rowNumber;">
                    <thead>
                        <tr>
                            <th colspan="5">
                                <h3>Pembelian Lainya</h3>
                            </th>
                        </tr>
                        <tr>
                            <th width="150px">Tanggal</th>
                            <th>Nama</th>
                            <th width="10px">jumlah</th>
                            <th>Harga</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $month_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->date); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->unit); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><?php echo e($item->unit * $item->price); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <button class="export-costume btn btn-primary btn-block" id="exportAdditionalIten">
                    Export
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="<?php echo e(asset('public/js/table2excel.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $( document ).ready(function() {
        console.log( "ready!" );
        $( "#datefrom" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $( "#dateto" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $('[data-toggle="datepicker"]').datepicker({
            autoHide: true,
            zIndex: 2048,
            dateFormat: 'yy-mm-dd'
        });
        $("#exportAdditionalIten").click(function(){
            var table2excel = new Table2Excel({
                defaultFileName: "Bookkeeping Costume",
                Number : true
            }
            );
            table2excel.export(document.getElementById("export"));
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/additional-item/export.blade.php ENDPATH**/ ?>