
<?php $__env->startSection('title'); ?> Laporan Penjualan <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/laporan.css')); ?>">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-warning alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
     <i class="fa fa-check-circle"></i> <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">Laporan Penjualan</h3>
    </div>
    <div class="panel-body">
        <form action="<?php echo e(route('jurnal-penjualan.index')); ?>" method="GET">
            <div class="row">
                <div class="col-md-2" >
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input class="form-control datepicker" placeholder="dari tanggal" id="from" type="datetime" value="<?php echo e($from? $from : ''); ?>" name="from">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="input-group">
                        <input class="form-control datepicker" placeholder="sampai tanggal" id="to" value="<?php echo e($to? $to : ''); ?>" type="datetime" name="to">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <select class="form-control" name="market_id">
                            <option value="">Pasar</option>
                            <<?php $__currentLoopData = $select_buyer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $by): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($by->id); ?>" <?php echo e($by->id == $market ? 'selected' : ''); ?> ><?php echo e($by->market); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </div>
        </form>
        <br>
        <?php if($profit == null): ?>
        <?php else: ?>
            <?php
            $income_total = [];
            ?>
            <?php $__currentLoopData = $profit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $akomodasi = $pr->tools + $pr->packing + $pr->shipping_charges;
                    $total_akomodasi = $akomodasi * $pr->tonase;
                    $sum_income = $pr->income - $pr->price - $total_akomodasi;
                    array_push($income_total, $sum_income);
                    ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
                    $sum_profit = array_sum($income_total);
            ?>
        <?php endif; ?>

        
        <div class="table-costume-additional-item">
            <table class="table table-striped table-bordered costume-export" style="counter-reset: rowNumber;">
                <thead>
                    <?php if($dvitem == null): ?>
                    <?php else: ?>
                    <?php if($market): ?>
                    <?php $__currentLoopData = $buyer->where('id',$market); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th colspan="8" class="text-center" style="text-align: center"><?php echo e($item->market); ?></th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    <tr>
                        <th colspan="8">
                            <h3>Laporan Penjualan</h3>
                        </th>
                    </tr>
                    <tr>
                        <th>Tanggal</th>
                        <th colspan="7">: <span> </span> <?php echo e($from); ?> - <?php echo e($to); ?></th>
                    </tr>
                    <tr>
                        <th>Tanggal</th>
                        <th>Nama</th>
                        <th>Pasar</th>
                        <th colspan="2">Tonase</th>
                        <th>Harga</th>
                        <th>Nota</th>
                        <th>Penjualan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($dvitem == null): ?>
                    <?php else: ?>
                    <?php $__currentLoopData = $dvitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $buyer->where('id',$item->buyer_Id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $by): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->date_time); ?></td>
                        <td><?php echo e($by->name); ?></td>
                        <td><?php echo e($by->market); ?></td>
                        <td><?php echo e($item->new_tonase); ?></td>
                        <td width="1px" class="text-center">Kg</td>
                        <td>Rp.<?php echo e(number_format($item->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($item->note_id); ?></td>
                        <td>Rp.<?php echo e(number_format($item->income, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr>
                        <th colspan="7">Total</th>
                        <th>
                            <?php if($profit == null): ?>
                            <?php else: ?>
                                Rp.<?php echo e(number_format($profit->sum('income'), 2, ',', '.')); ?>

                            <?php endif; ?>
                        </th>
                    </tr>
                    <tr>
                        <td colspan="5" style="border: 0px; background-color: white;"></td>
                    </tr>
                    <tr>
                        <td colspan="5" style="border: 0px; background-color: white;"></td>
                    </tr>
                    <tr>
                        <th colspan="5" style="background-color: white;">Total Keseluruhan</th>
                    </tr>
                    <tr>
                        <th>Pasar</th>
                        <th>Akomodasi</th>
                        <th>Harga</th>
                        <th>Penjualan</th>
                        <th>Kenutungan</th>
                    </tr>
                    <?php if($profit == null): ?>
                    <?php else: ?>
                    <?php $__currentLoopData = $profit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $by): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $addakomodasi = $by->tools + $by->packing + $by->shipping_charges;
                    $addtotal_akomodasi = $addakomodasi * $by->tonase;
                    $addsum_income = $by->income - $by->price - $addtotal_akomodasi;
                    ?>
                    <tr>
                        <td><?php echo e($by->market); ?></td>
                        <td>Rp.<?php echo e(number_format($addtotal_akomodasi, 2, ',', '.')); ?></td>
                        <td>Rp.<?php echo e(number_format($by->price, 2, ',', '.')); ?></td>
                        <td>Rp.<?php echo e(number_format($by->income, 2, ',', '.')); ?></td>
                        <td>
                            <?php if($addtotal_akomodasi == 0): ?>
                                Rp.0,00
                            <?php else: ?>
                            Rp.<?php echo e(number_format($by->income - $by->price - $addtotal_akomodasi, 2, ',', '.')); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($items == null): ?>
                        <?php else: ?>
                        </tr>
                        <tr>
                            <th colspan="4">Total</th>
                            <th>
                                Rp.<?php echo e(number_format( $sum_profit, 2, ',', '.')); ?>

                        </tr>
                        <?php endif; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <button class="export-costume btn btn-primary btn-block" id="exportCostume">
            Export
        </button>
        

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="<?php echo e(asset('public/js/table2excel.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $( document ).ready(function() {
        console.log( "ready!" );
        $( "#from" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $( "#to" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $("#dateFrom").datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $("#dateTo").datepicker({
            dateFormat: 'yy-mm-dd'
        })
        $("#exportCostume").click(function(){
            var table2excel = new Table2Excel({
                defaultFileName: "Bookkeeping Costume",
                Number : true,
            }
            );
            table2excel.export(document.getElementsByClassName("costume-export"));
        })
        $("#exportPembelian").click(function(){
            const dateFrom = $("#dateFrom").val()
            const dateTo = $("#dateTo").val()
            if( dateFrom == '' || dateTo == ''){
                alert("pilih tanggal atau pembayaran terlebih dahulu")
            }else{
                var table2excel = new Table2Excel({
                    defaultFileName: "Bookkeeping Pembelian",
                    Number : true,
                }
                );
                table2excel.export(document.getElementById("export-pembelian"));
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/jurnal-penjualan/index.blade.php ENDPATH**/ ?>