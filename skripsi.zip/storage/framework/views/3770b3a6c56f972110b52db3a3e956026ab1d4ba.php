<?php $__env->startSection('title'); ?> Edit Barang  <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title">Edit Data</h3>
		</div>
		<div class="panel-body">
			<form action="<?php echo e(route('barang.update',$item->id)); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo e(method_field('PUT')); ?>

				<input type="hidden" name="seller_id" value="<?php echo e($item->seller_id); ?>">
                <label for="tonase">Tonase</label>
                <div class="input-group">
                  <input type="text" class="form-control" name="tonase" value="<?php echo e($item->tonase); ?>">
                  <span class="input-group-addon">Kg</span>
                </div>
                <label for="price">Harga</label>
                <div class="input-group">
                  <span class="input-group-addon">Rp</span>
                  <input type="text" class="form-control" name="price" value="<?php echo e($item->price); ?>">
                </div>
                <div class="form-group">
                  <label for="payment">Pembayaran</label>
                  <select class="form-control" name="payment">
                    <option value="" >Pembayaran</option>
                    <option value="debt" <?php if($item->payment == 'debt'): ?>selected <?php endif; ?> >Hutang</option>
                    <option value="paid off" <?php if($item->payment == 'paid off'): ?>selected <?php endif; ?>>Lunas</option>
                  </select>
                </div>
                <button type=" submit " class="btn btn-primary">Save</button>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/salakscales/resources/views/users/barang/edit.blade.php ENDPATH**/ ?>