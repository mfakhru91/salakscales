
<?php $__env->startSection('title'); ?>Penjualan Detail <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-warning alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
     <i class="fa fa-check-circle"></i> <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="panel panel-profile">
  <div class="clearfix" style=" min-height: 450px">
    <!-- LEFT COLUMN -->
    <div class="profile-left">
      <!-- PROFILE HEADER -->
      <div class="profile-header">
        <div class="overlay"></div>
        <div class="profile-main">
          <img src="" class="img-circle" alt="Avatar" style="object-fit: cover; height: 100px; width: 100px;">
          <h3 class="name"></h3>
          <span class="online-status status-available">Available</span>
        </div>
        <div class="profile-stat">
          <div class="row">

          </div>
        </div>
      </div>
      <!-- END PROFILE HEADER -->
      <!-- PROFILE DETAIL -->
      <div class="profile-detail">
        <div class="profile-info">
          <h4 class="heading">Basic Info</h4>
          <ul class="list-unstyled list-justify">
            <li>Nama <span><?php echo e($buyyers->name); ?></span></li>
            <li>No Telp <span><?php echo e($buyyers->no_telp); ?></span></li>
            <li>Alamat <span><?php echo e($buyyers->address); ?></span></li>
          </ul>
        </div>
        <div class="text-center"><a href="<?php echo e(route('pembelian.edit',$buyyers->id)); ?>" class="btn btn-primary">Edit Profile</a></div>
      </div>
      <!-- END PROFILE DETAIL -->
    </div>
    <!-- END LEFT COLUMN -->
    <!-- RIGHT COLUMN -->
    <div class="profile-right">
      <h4 class="heading"><?php echo e($buyyers->name); ?></h4>
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="margin-bottom: 10px;">
          Kirim Barang <i class="fa fa-shopping-cart"></i>
      </button>
      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Baru</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form class="" action="<?php echo e(route('penjualan.add.item')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <p>Barang Siap Jual</p>
                <div class="row">
                    <div class="col-md-3">
                        <label for="tonase">Tonase</label>
                        <div class="input-group">
                            <input type="text" class="form-control" disabled id="tonaseValue" value="<?php if($dvitem == null): ?> 0 <?php else: ?> <?php echo e($dvitem->tonase); ?> <?php endif; ?>">
                            <span class="input-group-addon">Kg</span>
                        </div>
                        <input type="text" class="form-control" name="old_tonase" style="display: none" id="oldTonase" value="">
                        <input type="text" class="form-control" style="display: none" id="totalTonase" value="<?php if($dvitem == null): ?> 0 <?php else: ?> <?php echo e($dvitem->tonase); ?> <?php endif; ?>">
                    </div>
                </div>
                <hr>
                <input type="hidden" name="buyyer_id" value="<?php echo e($buyyers->id); ?>">
                <label for="tonase">Tonase</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="valtonase" name="new_tonase" value="">
                  <span class="input-group-addon">Kg</span>
                </div>
                <a href="#" class="btn btn-primary" style="margin-top: 10px" id="getTotal">Hitung</a>
                <br>
                <label for="price">Harga</label>
                <div class="input-group">
                  <span class="input-group-addon">Rp</span>
                  <input type="text" class="form-control" id="price" name="price" value="">
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Kirim <i class="fa fa-shopping-cart"></i></button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-heading">
          <h3 class="panel-title">Tansaksi Pembelian</h3>
        </div>
        <div class="panel-body">
          <?php if($errors->has('item')): ?>
          <span class="help-block" ><?php echo e($errors->first('item')); ?></span>
          <?php endif; ?>
          <div class="<?php echo e($errors->has('item')? 'has-error':''); ?> "></div>
          <form action="<?php echo e(route('print.item')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="saller_id" value="<?php echo e($buyyers->id); ?>">
            <button type="submit" class="btn btn-info"><span class="lnr lnr-printer"></span> Print</button>
            <table class="table table-striped">
            <thead>
              <tr>
                <th> <input class="form-check-input" type="checkbox" id="checkall" value="option2"> </th>
          </form>
                <th>TANGGAL</th>
                <th>TONASE</th>
                <th>HARGA</th>
                <th>NO NOTA</th>
                <th>ACTION</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $buyyerItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td> <input class="form-check-input itemchecked" type="checkbox" name="item[<?php echo e($item->id); ?>]" value="<?php echo e($item->id); ?>"> </td>
                  <td> <?php echo e($item->date_time); ?> </td>
                  <td> <?php echo e($item->new_tonase); ?> </td>
                  <td> Rp. <?php echo e(number_format($item->price, 2, ',', '.')); ?> </td>
                  <td>
                    <button type="submit" class="btn btn-light"><span class="lnr lnr-printer"></span> 1(fake) </button>
                  </td>
                  <td>
                    <a href="<?php echo e(route('barang.edit',$item->id)); ?>" class="btn btn-warning"><i class="lnr lnr-pencil"></i></a>
                    <a href="<?php echo e(route('item.delete.pembelian',$item->id)); ?>" class="btn btn-danger"><span class="lnr lnr-trash"></span></a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- END RIGHT COLUMN -->
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    const user_id = <?php echo e($user); ?>

    $(document).ready(function() {
        $('#valtonase').click(function(){
            $.ajax({
                url:"http://localhost/salakscales/api/setting/"+user_id,
                type:"GET",
                async : true,
                success:function(result)
                {
                    let price = result.data[0].sell_price;
                    let getPrice = $('#totalPrice').val()
                    let totalTonase = $('#totalTonase').val()
                    $('#getTotal').click(function() {
                        let total = Number(totalTonase)- $('#valtonase').val()
                        if (total < 0 ){
                            alert('berat yang anda masukan berlebih')
                        }else{
                            let getPriceTotal = price * $('#valtonase').val()
                            $('#price').val(getPriceTotal)
                            $('#tonaseValue').val(total)
                            $('#oldTonase').val(total)
                        }
                    })
                }
            });
        })
        $('#checkall').click(function() {
          if($('#checkall').prop('checked')== true){
            $('.itemchecked').prop('checked',true)
          }else{
            $('.itemchecked').prop('checked',false)
          }
        })
        $('.itemchecked').click(function() {
          $('#checkall').prop('checked',false)
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\salakscales\resources\views/users/penjualan/show.blade.php ENDPATH**/ ?>