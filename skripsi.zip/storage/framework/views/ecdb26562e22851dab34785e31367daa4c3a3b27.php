<?php $__env->startSection('title'); ?> barang <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<button type="button" class="btn btn-primary pb-3" data-toggle="modal" data-target="#exampleModal">
          Tambah Pelajaran <i class="lnr lnr-plus-circle"></i>
      </button>
      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form class="" action="<?php echo e(route('barang.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="payment">Pembeli</label>
                  <select class="form-control" name="seller_id">
                    <option value="" selected>Pembeli</option>
                    <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    	<option value="<?php echo e($seller->id); ?>"><?php echo e($seller->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <label for="tonase">Tonase</label>
                <div class="input-group">
                  <input type="text" class="form-control" name="tonase" value="">
                  <span class="input-group-addon">Kg</span>
                </div>
                <label for="price">Harga</label>
                <div class="input-group">
                  <span class="input-group-addon">Rp</span>
                  <input type="text" class="form-control" name="price" value="">
                </div>
                <div class="form-group">
                  <label for="payment">Pembayaran</label>
                  <select class="form-control" name="payment">
                    <option value="" selected>Pembayaran</option>
                    <option value="debt">Hutang</option>
                    <option value="paid off">Lunas</option>
                  </select>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Tambah Pelajaran <i class="lnr lnr-plus-circle"></i></button>
              </form>
            </div>
          </div>
        </div>
      </div>
	<div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title">Daftar Barang</h3>
		</div>
		<div class="panel-body">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>NAMA PENJUAL</th>
						<th>TONASE</th>
						<th>PRICE</th>
						<th>PAYMENT</th>
						<th>NO NOTA</th>
						<th>ACTION</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $sellers->where('id',$item->seller_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><a href="<?php echo e(route('pembelian.show',$seller->id)); ?>" class="text-info"><?php echo e($seller->name); ?></a></td>
						<td><?php echo e($item->tonase); ?></td>
						<td><?php echo e($item->price); ?></td>
						<td><?php echo e($item->payment); ?></td>
						<td>
							<form action="<?php echo e(route('print.note')); ?>" id="note" method="post">
		                      <?php echo csrf_field(); ?>
		                      <input type="hidden" name="saller_id" value="<?php echo e($item->seller_id); ?>">
		                      <input type="hidden" name="note" value="<?php echo e($item->note_id); ?>">
		                      <?php if($item->note_id): ?>
		                      <button type="submit" class="btn btn-light"><span class="lnr lnr-printer"></span> <?php echo e($item->note_id); ?></button>
		                      <?php endif; ?>
		                    </form> 
						</td>
						<td>
							<a href="<?php echo e(route('barang.edit',$item->id)); ?>" class="btn btn-warning"><i class="lnr lnr-pencil"></i></a>
							<a href="<?php echo e(route('item.delete',$item->id)); ?>" class="btn btn-danger"><span class="lnr lnr-trash"></span></a>  
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/salakscales/resources/views/users/barang/index.blade.php ENDPATH**/ ?>