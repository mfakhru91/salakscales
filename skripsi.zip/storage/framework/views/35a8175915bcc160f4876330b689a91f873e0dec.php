<?php $__env->startSection('title'); ?>Pembelian show <?php echo e($seller->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-warning alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
     <i class="fa fa-check-circle"></i> <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="panel panel-profile">
  <div class="clearfix" style=" min-height: 450px">
    <!-- LEFT COLUMN -->
    <div class="profile-left">
      <!-- PROFILE HEADER -->
      <div class="profile-header">
        <div class="overlay"></div>
        <div class="profile-main">
          <img src="" class="img-circle" alt="Avatar" style="object-fit: cover; height: 100px; width: 100px;">
          <h3 class="name"></h3>
          <span class="online-status status-available">Available</span>
        </div>
        <div class="profile-stat">
          <div class="row">
            <div class="col-md-4 stat-item">
              <span>Mata Pelajaran</span>
            </div>
            <div class="col-md-4 stat-item">
              <?php echo e($paidOff->item->sum('price')); ?> <span>Profit</span>
            </div>
            <div class="col-md-4 stat-item">
              <?php echo e($paidOff->item->count()); ?> <span>Tonase</span>
            </div>
          </div>
        </div>
      </div>
      <!-- END PROFILE HEADER -->
      <!-- PROFILE DETAIL -->
      <div class="profile-detail">
        <div class="profile-info">
          <h4 class="heading">Basic Info</h4>
          <ul class="list-unstyled list-justify">
            <li>Nama <span><?php echo e($seller->name); ?></span></li>
            <li>No Telp <span><?php echo e($seller->no_telp); ?></span></li>
            <li>Alamat <span><?php echo e($seller->address); ?></span></li>
          </ul>
        </div>
        <div class="text-center"><a href="<?php echo e(route('pembelian.edit',$seller->id)); ?>" class="btn btn-primary">Edit Profile</a></div>
      </div>
      <!-- END PROFILE DETAIL -->
    </div>
    <!-- END LEFT COLUMN -->
    <!-- RIGHT COLUMN -->
    <div class="profile-right">
      <h4 class="heading"><?php echo e($seller->name); ?></h4>
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
          Tambah Pelajaran <i class="lnr lnr-plus-circle"></i>
      </button>
      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form class="" action="<?php echo e(route('barang.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                <label for="tonase">Tonase</label>
                <div class="input-group">
                  <input type="text" class="form-control" name="tonase" value="">
                  <span class="input-group-addon">Kg</span>
                </div>
                <label for="price">Harga</label>
                <div class="input-group">
                  <span class="input-group-addon">Rp</span>
                  <input type="text" class="form-control" name="price" value="">
                </div>
                <div class="form-group">
                  <label for="payment">Pembayaran</label>
                  <select class="form-control" name="payment">
                    <option value="" selected>Pembayaran</option>
                    <option value="debt">Hutang</option>
                    <option value="paid off">Lunas</option>
                  </select>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Tambah Pelajaran <i class="lnr lnr-plus-circle"></i></button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-heading">
          <h3 class="panel-title">Tansaksi Pembelian</h3>
        </div>
        <div class="panel-body">
          <?php if($errors->has('item')): ?>
          <span class="help-block" ><?php echo e($errors->first('item')); ?></span>
          <?php endif; ?>
          <div class="<?php echo e($errors->has('item')? 'has-error':''); ?> "></div>
          <form action="<?php echo e(route('print.item')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="saller_id" value="<?php echo e($seller->id); ?>">
            <button type="submit" class="btn btn-info"><span class="lnr lnr-printer"></span> Print</button>
            <table class="table table-striped">
            <thead>
              <tr>
                <th> <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2"> </th>
          </form>
                <th>TANGGAL</th>
                <th>TONASE</th>
                <th>HARGA</th>
                <th>PEMBAYARAN</th>
                <th>NO NOTA</th>
                <th>ACTION</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $seller->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td> <input class="form-check-input" type="checkbox" name="item[<?php echo e($item->id); ?>]" value="<?php echo e($item->id); ?>"> </td>
                  <td> <?php echo e($item->date($item->created_at)); ?> </td>
                  <td> <?php echo e($item->tonase); ?> </td>
                  <td> <?php echo e($item->price); ?> </td>
                  <td> <?php echo e($item->payment); ?> </td>
                  <td> 
                    <form action="<?php echo e(route('print.note')); ?>" id="note" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="saller_id" value="<?php echo e($seller->id); ?>">
                      <input type="hidden" name="note" value="<?php echo e($item->note_id); ?>">
                      <?php if($item->note_id): ?>
                      <button type="submit" class="btn btn-light"><span class="lnr lnr-printer"></span> <?php echo e($item->note_id); ?></button>
                      <?php endif; ?>
                    </form> 
                  </td>
                  <td> 
                    <a href="<?php echo e(route('barang.edit',$item->id)); ?>" class="btn btn-warning"><i class="lnr lnr-pencil"></i></a>
                    <a href="<?php echo e(route('item.delete',$item->id)); ?>" class="btn btn-danger"><span class="lnr lnr-trash"></span></a>    
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- END RIGHT COLUMN -->
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script>
function noteSubmit() {
  document.getElementById("note").submit();
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/salakscales/resources/views/users/pembelian/show.blade.php ENDPATH**/ ?>