
<?php $__env->startSection('title'); ?>Print Data <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
  <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="panel">
    <div class="panel-heading">
      <h3 class="panel-title">PRINT NOTA</h3>
    </div>
    <div class="panel-body" id="nota">
      <div class="row">
        <div class="col-xs-12">
          <table class="">
            <tr>
              <td rowspan="7">
                <img src="<?php echo e(asset('public/image/logo_nota.png')); ?>" height="100px" alt="logo">
              </td>
            </tr>
            <tr>
              <th colspan="3" style="width: 200px">
                <h3>Nota Salak Pondoh</h3>
              </th>
            </tr>
            <tr>
              <td style="width: 90px;">Date</td>
              <td style="width: 30px;">:</td>
              <td><?php echo e(now()->format('d M Y')); ?></td>
            </tr>
            <?php if($note_id == null): ?>

            <?php else: ?>
            <tr>
              <td>No Nota</td>
              <td>:</td>
              <td><?php echo e($note_id); ?></td>
            </tr>
            <?php endif; ?>
            <tr>
              <td>Nama</td>
              <td>:</td>
              <td><?php echo e($buyer->name); ?></td>
            </tr>
            <tr>
              <td>Pasar</td>
              <td>:</td>
              <td><?php echo e($buyer->market); ?></td>
            </tr>
            <tr>
              <td>Alamat</td>
              <td>:</td>
              <td><?php echo e($buyer->address); ?></td>
            </tr>
          </table>
        </div>
        <div class="col">

        </div>
      </div>
      <hr>
      <table class="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Tonase</th>
            <th>Harga</th>
            <th>Penjualan</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->date($item->created_at)); ?></td>
            <td><?php echo e($item->new_tonase); ?> Kg</td>
            <td>Rp.<?php echo e(number_format($item->price, 2, ',', '.')); ?></td>
            <td>Rp.<?php echo e(number_format($item->income, 2, ',', '.')); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr >
            <td colspan="1" class="text-right">
              <b>Total</b>
            </td>
            <td> <?php echo e($items->sum('new_tonase')); ?> Kg</td>
            <td>Rp.<?php echo e(number_format($items->sum('price') ,2 ,',', '.')); ?></td>
            <td>Rp.<?php echo e(number_format($items->sum('income') ,2 ,',', '.')); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="panel-footer">
      <div class="row">
        <div class="col-md-1">
          <?php if($item->note_id): ?>
          <button type="button"  class="btn btn-info" onclick="printJS({ printable: 'nota', type: 'html', css:'https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css' })">
            <span class="lnr lnr-printer"></span> Print
          </button></div>
          <?php endif; ?>
        <div class="col-md-1">
          <form action="<?php echo e(route('note.buyer.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="buyer_id" value="<?php echo e($buyer->id); ?>">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="hidden" name="item_id[<?php echo e($item->id); ?>]" value="<?php echo e($item->id); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" name="price_total" value="<?php echo e($items->sum('price')); ?>">
            <input type="hidden" name="tonase_total" value="<?php echo e($items->sum('new_tonase')); ?>">
            <button class="btn btn-primary"><span class="lnr lnr-file-empty"></span> Save</button>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/barang/byprint.blade.php ENDPATH**/ ?>