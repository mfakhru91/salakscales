<div id="sidebar-nav" class="sidebar">
  <div class="sidebar-scroll">
    <nav>
      <ul class="nav">
        <li><a href="<?php echo e(route('dashboard.index')); ?>" class="<?php echo e(Request::routeIs('dashboard.index') ? 'active' : ''); ?>"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
        <li>
          <a href="#subPages" data-toggle="collapse" class="collapsed <?php if(Request::routeIs('pembelian.index') || Request::routeIs('penjualan.index')): ?> active <?php endif; ?>"><i class="lnr lnr-users"></i> <span>Transaksi</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
          <div id="subPages" class="collapse ">
            <ul class="nav">
              <li><a href="<?php echo e(route('pembelian.index')); ?>" class="<?php echo e(Request::routeIs('pembelian.index') ? 'active' : ''); ?>"><i class="lnr lnr-cart"></i><span>Pembelian</span></a></li>
              <li><a href="<?php echo e(route('penjualan.index')); ?>" class="<?php echo e(Request::routeIs('penjualan.index') ? 'active' : ''); ?>"><i class="lnr lnr-briefcase"></i><span>Penjualan</span></a></li>
            </ul>
          </div>
        </li>
        <li><a href="<?php echo e(route('barang.index')); ?>" class="<?php echo e(Request::routeIs('barang.index')? 'active' : ''); ?>"><i class="lnr lnr-database"></i><span>Barang</span></a></li>
        <li>
          <a href="#laporan" data-toggle="collapse" class="collapsed <?php if(Request::routeIs('laporan.index') || Request::routeIs('bookkeeping.index')): ?> active <?php endif; ?>"><span class="lnr lnr-book"></span> <span>Laporan</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
          <div id="laporan" class="collapse ">
            <ul class="nav">
              <li><a href="<?php echo e(route('jurnal-ledger.index')); ?>" class="<?php echo e(Request::routeIs('jurnal-ledger.index') ? 'active' : ''); ?>"<span>General ledger</span></a></li>
              <li><a href="<?php echo e(route('jurnal-pembelian.index')); ?>" class="<?php echo e(Request::routeIs('jurnal-penjualan.index')? 'active' : ''); ?>"><span>Laporan Pembelian</span></a></li>
              <li><a href="<?php echo e(route('jurnal-penjualan.index')); ?>" class="<?php echo e(Request::routeIs('jurnal-penjualan.index')? 'active' : ''); ?>"><span>Laporan Penjualan</span></a></li>
              <li><a href="<?php echo e(route('additional-item.index')); ?>" class="<?php echo e(Request::routeIs('bookkeeping.index') ? 'active' : ''); ?>"<span>Pembelian Lain</span></a></li>
              <li><a href="<?php echo e(route('laporan-laba-rugi.index')); ?>" class="<?php echo e(Request::routeIs('laporan-laba-rugi.index') ? 'active' : ''); ?>"<span>Laporan Laba Rugi</span></a></li>
            </ul>
          </div>
        </li>
        
        <li><a href="<?php echo e(route('setting.index')); ?>" class=""><i class="lnr lnr-cog"></i> <span>Setting</span></a></li>
      </ul>
    </nav>
  </div>
</div>
<?php /**PATH E:\xampp\htdocs\skripsi\resources\views/layouts/includes/_sidebar.blade.php ENDPATH**/ ?>