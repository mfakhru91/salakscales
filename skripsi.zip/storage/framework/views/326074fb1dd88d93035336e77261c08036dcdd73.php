
<?php $__env->startSection('title'); ?> barang <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/laporan.css')); ?>">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-warning alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
     <i class="fa fa-check-circle"></i> <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">Pembelian Lainya</h3>
    </div>
    <div class="panel-body">
        <form action="<?php echo e(route('additional-item.index')); ?>" method="GET">
            <div class="row" style="margin-bottom: 10px;">
                <div class="col-md-2" >
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input class="form-control datepicker" placeholder="dari tanggal" id="datefrom" type="datetime" name="from">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2" >
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input class="form-control datepicker" placeholder="sampai tanggal" id="dateto" type="datetime" name="to">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </div>
        </form>

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
            Tambah Barang
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('additional-item.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Tanggal Pembelian</label>
                            <input type="text" class="form-control" name="date" data-toggle="datepicker" placeholder="tanggal pembelian">
                            <?php if($errors->has('date')): ?>
                                <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="name">Nama Barang</label>
                            <input type="text" class="form-control" id="itemName" name="item_name" placeholder="nama barang">
                            <?php if($errors->has('item_name')): ?>
                                <span class="help-block"><?php echo e($errors->first('item_name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="unit">Jumlah Barang</label>
                            <input type="number" class="form-control" id="itemUnit" name="item_unit" placeholder="jumlah barang">
                            <?php if($errors->has('item_unit')): ?>
                                <span class="help-block"><?php echo e($errors->first('item_unit')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="unit">Harga Barang</label>
                            <input type="number" class="form-control" id="itemUnit" name="item_price" placeholder="harga barang">
                            <?php if($errors->has('item_price')): ?>
                                <span class="help-block"><?php echo e($errors->first('item_price')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah Barang</button>
                    </form>
                </div>
                </div>
            </div>
        </div>
        <table style="margin-top: 10px" class="table table-striped table-bordered"  id="export" style="counter-reset: rowNumber;">
            <thead>
                <tr>
                    <th colspan="7">
                        <h3>Pembelian Lainya</h3>
                    </th>
                </tr>
                <tr>
                    <th>Tanggal</th>
                    <th>Nama</th>
                    <th>jumlah</th>
                    <th>Harga</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $month_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->date); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->unit); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->unit * $item->price); ?></td>
                    <td>
                        <a href="<?php echo e(route('additional-item.edit',$item->id)); ?>" class="btn btn-warning"><i class="lnr lnr-pencil"></i></a>
                        <a href="<?php echo e(route('additional-item.delete',$item->id)); ?>" class="btn btn-danger"><span class="lnr lnr-trash"></span></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(Route('additional-item.export')); ?>" class="btn btn-primary btn-block">Export</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="<?php echo e(asset('public/js/table2excel.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $( document ).ready(function() {
        console.log( "ready!" );
        $( "#datefrom" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $( "#dateto" ).datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $('[data-toggle="datepicker"]').datepicker({
            autoHide: true,
            zIndex: 2048,
            dateFormat: 'yy-mm-dd'
        });
        $("#exportAdditionalIten").click(function(){
            var table2excel = new Table2Excel({
                defaultFileName: "Bookkeeping Costume",
                Number : true
            }
            );
            table2excel.export(document.getElementById("export"));
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/additional-item/index.blade.php ENDPATH**/ ?>