
<?php $__env->startSection('title'); ?> barang <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title text-center">Confirmasi Barang Siap Jual</h3>
    </div>
    <div class="panel-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>NAMA PENJUAL</th>
                    <th>TONASE</th>
                    <th>NO NOTA</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->seller_id); ?></td>
                    <td><?php echo e($item->tonase); ?></td>
                    <td>
                        <form action="<?php echo e(route('print.note')); ?>" id="note" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="saller_id" value="<?php echo e($item->seller_id); ?>">
                            <input type="hidden" name="note" value="<?php echo e($item->note_id); ?>">
                            <?php if($item->note_id): ?>
                            <button type="submit" class="btn btn-light"><span class="lnr lnr-printer"></span> <?php echo e($item->note_id); ?></button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('barang.dvitem')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <tr>
                        <th class="bg-primary">Total</th>
                        <th class="bg-primary"><?php echo e($tonase); ?> Kg</th>
                        <th class="bg-primary"></th>
                    </tr>
                    <tr>
                        <td colspan="4" class="text-center">
                            <input type="hidden" value="<?php echo e($tonase); ?>" name="tonase">
                            <?php $__currentLoopData = $item_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="items_id[]" value="<?php echo e($id); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-primary">Confrim</button>
                        </td>
                    </tr>
                </form>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skripsi\resources\views/users/dvbarang/index.blade.php ENDPATH**/ ?>