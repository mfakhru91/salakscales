<?php $__env->startSection('title'); ?>Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel">
	<div class="panel-heading">
		<h3 class="panel-title">Weekly Overview</h3>
	</div>
	<div class="panel-body">
		<div class="row">
			<div class="col-md-3">
				<div class="metric">
					<span class="icon"><i class="fa fa-download"></i></span>
					<p>
						<span class="number"><?php echo e($sellers->sum('item->price')); ?></span>
						<span class="title">Profit</span>
					</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="metric">
					<span class="icon"><i class="fa fa-download"></i></span>
					<p>
						<span class="number">1,252</span>
						<span class="title">Downloads</span>
					</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="metric">
					<span class="icon"><i class="fa fa-download"></i></span>
					<p>
						<span class="number">1,252</span>
						<span class="title">Downloads</span>
					</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="metric">
					<span class="icon"><i class="fa fa-download"></i></span>
					<p>
						<span class="number">1,252</span>
						<span class="title">Downloads</span>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/salakscales/resources/views/users/dashboard/index.blade.php ENDPATH**/ ?>